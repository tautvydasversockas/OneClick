namespace $rootnamespace$.$fileinputname$
{
    public class $fileinputname$RequestHandlerSettings
    {
    }
}