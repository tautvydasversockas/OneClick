namespace $rootnamespace$.$fileinputname$
{
    public class $fileinputname$Request
    {
    }
}